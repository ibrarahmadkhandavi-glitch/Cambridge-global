# CarBridge Global MVP

Open `index.html` in a browser. This is a front-end MVP/prototype implementing:
- Find Any Car search
- Find My Car buyer request
- Dealer registration
- Demo vehicle listings
- Deal Now flow
- Inspection/document/payment workflow display
- Admin dashboard with browser-local demo data

Important: this prototype does NOT process real payments, escrow, identity verification, customs clearance, ownership transfer, or real vehicle inspection. Those require production integrations, contracts, and legal/compliance review.
